"""Creates the git history for the Tillpoint assignment: one commit for each fix.

Run it ONCE, from the folder that contains server.py, NOTES.md, tillpoint and tests:
    python make_commits.py
"""
import base64
import os
import subprocess
import sys

PATCHES = [
    ('Report 1: ignore repeated payment webhooks', """
ZGlmZiAtLWdpdCBhL3RpbGxwb2ludC9wYXltZW50cy5weSBiL3RpbGxwb2ludC9wYXltZW50cy5weQppbmRleCBjMDY0YTNiLi5l
OTA1YWZjIDEwMDY0NAotLS0gYS90aWxscG9pbnQvcGF5bWVudHMucHkKKysrIGIvdGlsbHBvaW50L3BheW1lbnRzLnB5CkBAIC0x
OSwxNCArMTksMjcgQEAgY2xhc3MgUGF5bWVudHM6CiAgICAgICAgICAgICByYWlzZSBQYXltZW50RXJyb3IoZiJwYXltZW50IGZv
ciB1bmtub3duIG9yZGVyIHtldmVudFsnb3JkZXJfaWQnXX0iKQogICAgICAgICBpZiBvcmRlclsic3RhdHVzIl0gPT0gImNhbmNl
bGxlZCI6CiAgICAgICAgICAgICByYWlzZSBQYXltZW50RXJyb3IoZiJvcmRlciB7b3JkZXJbJ2lkJ119IGlzIGNhbmNlbGxlZCIp
Ci0gICAgICAgIHNlbGYuY29ubi5leGVjdXRlKAotICAgICAgICAgICAgIklOU0VSVCBJTlRPIHBheW1lbnRzIChvcmRlcl9pZCwg
ZXZlbnRfaWQsIGFtb3VudF9jZW50cywgcmVjZWl2ZWRfYXQpIFZBTFVFUyAoPywgPywgPywgPykiLAotICAgICAgICAgICAgKG9y
ZGVyWyJpZCJdLCBldmVudFsiaWQiXSwgZXZlbnRbImFtb3VudF9jZW50cyJdLCBkYi50b19pc28obm93IG9yIGRiLnV0Y25vdygp
KSksCi0gICAgICAgICkKLSAgICAgICAgaWYgb3JkZXJbInN0YXR1cyJdID09ICJwZW5kaW5nIiBhbmQgc2VsZi5wYWlkX2NlbnRz
KG9yZGVyWyJpZCJdKSA+PSBvcmRlclsidG90YWxfY2VudHMiXToKLSAgICAgICAgICAgIHNlbGYuY29ubi5leGVjdXRlKCJVUERB
VEUgb3JkZXJzIFNFVCBzdGF0dXMgPSAncGFpZCcgV0hFUkUgaWQgPSA/IiwgKG9yZGVyWyJpZCJdLCkpCi0gICAgICAgICAgICBy
ZXR1cm4gInBhaWQiCi0gICAgICAgIHJldHVybiBvcmRlclsic3RhdHVzIl0KKyAgICAgICAgc2VsZi5jb25uLmV4ZWN1dGUoIkJF
R0lOIElNTUVESUFURSIpCisgICAgICAgIHRyeToKKyAgICAgICAgICAgICMgVGhlIHByb3ZpZGVyIHJldHJpZXMgYSBkZWxpdmVy
eSB1bnRpbCBpdCBnZXRzIGEgMnh4LCBzbyB0aGUgc2FtZSBldmVudCBpZCBjYW4gYXJyaXZlIGFnYWluLgorICAgICAgICAgICAg
IyBJZiB3ZSBhbHJlYWR5IHN0b3JlZCB0aGlzIGV2ZW50IGlkLCBkbyBub3RoaW5nIGFuZCBqdXN0IHJlcG9ydCB0aGUgb3JkZXIn
cyBjdXJyZW50IHN0YXR1cy4KKyAgICAgICAgICAgIHNlZW4gPSBzZWxmLmNvbm4uZXhlY3V0ZSgiU0VMRUNUIDEgRlJPTSBwYXlt
ZW50cyBXSEVSRSBldmVudF9pZCA9ID8iLCAoZXZlbnRbImlkIl0sKSkuZmV0Y2hvbmUoKQorICAgICAgICAgICAgaWYgc2VlbiBp
cyBub3QgTm9uZToKKyAgICAgICAgICAgICAgICBzZWxmLmNvbm4uZXhlY3V0ZSgiQ09NTUlUIikKKyAgICAgICAgICAgICAgICBy
ZXR1cm4gc2VsZi5jb25uLmV4ZWN1dGUoIlNFTEVDVCBzdGF0dXMgRlJPTSBvcmRlcnMgV0hFUkUgaWQgPSA/IiwgKG9yZGVyWyJp
ZCJdLCkpLmZldGNob25lKClbInN0YXR1cyJdCisgICAgICAgICAgICBzZWxmLmNvbm4uZXhlY3V0ZSgKKyAgICAgICAgICAgICAg
ICAiSU5TRVJUIElOVE8gcGF5bWVudHMgKG9yZGVyX2lkLCBldmVudF9pZCwgYW1vdW50X2NlbnRzLCByZWNlaXZlZF9hdCkgVkFM
VUVTICg/LCA/LCA/LCA/KSIsCisgICAgICAgICAgICAgICAgKG9yZGVyWyJpZCJdLCBldmVudFsiaWQiXSwgZXZlbnRbImFtb3Vu
dF9jZW50cyJdLCBkYi50b19pc28obm93IG9yIGRiLnV0Y25vdygpKSksCisgICAgICAgICAgICApCisgICAgICAgICAgICBzdGF0
dXMgPSBzZWxmLmNvbm4uZXhlY3V0ZSgiU0VMRUNUIHN0YXR1cyBGUk9NIG9yZGVycyBXSEVSRSBpZCA9ID8iLCAob3JkZXJbImlk
Il0sKSkuZmV0Y2hvbmUoKVsic3RhdHVzIl0KKyAgICAgICAgICAgIGlmIHN0YXR1cyA9PSAicGVuZGluZyIgYW5kIHNlbGYucGFp
ZF9jZW50cyhvcmRlclsiaWQiXSkgPj0gb3JkZXJbInRvdGFsX2NlbnRzIl06CisgICAgICAgICAgICAgICAgc2VsZi5jb25uLmV4
ZWN1dGUoIlVQREFURSBvcmRlcnMgU0VUIHN0YXR1cyA9ICdwYWlkJyBXSEVSRSBpZCA9ID8iLCAob3JkZXJbImlkIl0sKSkKKyAg
ICAgICAgICAgICAgICBzdGF0dXMgPSAicGFpZCIKKyAgICAgICAgICAgIHNlbGYuY29ubi5leGVjdXRlKCJDT01NSVQiKQorICAg
ICAgICBleGNlcHQgRXhjZXB0aW9uOgorICAgICAgICAgICAgc2VsZi5jb25uLmV4ZWN1dGUoIlJPTExCQUNLIikKKyAgICAgICAg
ICAgIHJhaXNlCisgICAgICAgIHJldHVybiBzdGF0dXMKIAogICAgIGRlZiBwYWlkX2NlbnRzKHNlbGYsIG9yZGVyX2lkKToKICAg
ICAgICAgcm93ID0gc2VsZi5jb25uLmV4ZWN1dGUoCg==
"""),
    ('Report 2: return stock when a pending order is cancelled', """
ZGlmZiAtLWdpdCBhL3RpbGxwb2ludC9vcmRlcnMucHkgYi90aWxscG9pbnQvb3JkZXJzLnB5CmluZGV4IGI5MDQ3ZjMuLjUwYTc2
MjMgMTAwNjQ0Ci0tLSBhL3RpbGxwb2ludC9vcmRlcnMucHkKKysrIGIvdGlsbHBvaW50L29yZGVycy5weQpAQCAtNTMsOSArNTMs
OSBAQCBjbGFzcyBPcmRlcnM6CiAgICAgICAgICAgICByYWlzZSBPcmRlckVycm9yKCJhIHNoaXBwZWQgb3JkZXIgY2Fubm90IGJl
IGNhbmNlbGxlZCIpCiAgICAgICAgIHNlbGYuY29ubi5leGVjdXRlKCJCRUdJTiBJTU1FRElBVEUiKQogICAgICAgICB0cnk6Ci0g
ICAgICAgICAgICBpZiBvcmRlclsic3RhdHVzIl0gPT0gInBhaWQiOgotICAgICAgICAgICAgICAgIGZvciBpdGVtIGluIG9yZGVy
WyJpdGVtcyJdOgotICAgICAgICAgICAgICAgICAgICBzZWxmLmNhdGFsb2cucmVsZWFzZShpdGVtWyJza3UiXSwgaXRlbVsicXR5
Il0pCisgICAgICAgICAgICAjIFN0b2NrIGlzIHRha2VuIHdoZW4gdGhlIG9yZGVyIGlzIGNyZWF0ZWQgKHN0YXR1cyBwZW5kaW5n
KSwgc28gZXZlcnkgY2FuY2VsbGVkIG9yZGVyIGdpdmVzIGl0IGJhY2suCisgICAgICAgICAgICBmb3IgaXRlbSBpbiBvcmRlclsi
aXRlbXMiXToKKyAgICAgICAgICAgICAgICBzZWxmLmNhdGFsb2cucmVsZWFzZShpdGVtWyJza3UiXSwgaXRlbVsicXR5Il0pCiAg
ICAgICAgICAgICBpZiBvcmRlclsiY291cG9uIl06CiAgICAgICAgICAgICAgICAgc2VsZi5jb25uLmV4ZWN1dGUoIlVQREFURSBj
b3Vwb25zIFNFVCB1c2VzID0gdXNlcyAtIDEgV0hFUkUgY29kZSA9ID8gQU5EIHVzZXMgPiAwIiwgKG9yZGVyWyJjb3Vwb24iXSwp
KQogICAgICAgICAgICAgc2VsZi5jb25uLmV4ZWN1dGUoIlVQREFURSBvcmRlcnMgU0VUIHN0YXR1cyA9ICdjYW5jZWxsZWQnIFdI
RVJFIGlkID0gPyIsIChvcmRlcl9pZCwpKQo=
"""),
    ('Report 3: calculate tax after the coupon discount', """
ZGlmZiAtLWdpdCBhL3RpbGxwb2ludC9wcmljaW5nLnB5IGIvdGlsbHBvaW50L3ByaWNpbmcucHkKaW5kZXggZWE5OTY3ZC4uM2E2
YzE3MSAxMDA2NDQKLS0tIGEvdGlsbHBvaW50L3ByaWNpbmcucHkKKysrIGIvdGlsbHBvaW50L3ByaWNpbmcucHkKQEAgLTQxLDgg
KzQxLDggQEAgZGVmIHJvdW5kX2hhbGZfdXAobnVtZXJhdG9yLCBkZW5vbWluYXRvcik6CiBkZWYgcHJpY2Vfb3JkZXIobGluZXMs
IHJlZ2lvbiwgY291cG9uPU5vbmUpOgogICAgICIiIlJldHVybiBkaWN0KHN1YnRvdGFsX2NlbnRzLCBkaXNjb3VudF9jZW50cywg
dGF4X2NlbnRzLCB0b3RhbF9jZW50cykuIiIiCiAgICAgc3ViID0gc3VidG90YWwobGluZXMpCi0gICAgdGF4ID0gdGF4X2Zvcihz
dWIsIHJlZ2lvbikKICAgICBkaXNjb3VudCA9IGRpc2NvdW50X2Zvcihjb3Vwb24sIHN1YikKKyAgICB0YXggPSB0YXhfZm9yKHN1
YiAtIGRpc2NvdW50LCByZWdpb24pCiAgICAgcmV0dXJuIHsKICAgICAgICAgInN1YnRvdGFsX2NlbnRzIjogc3ViLAogICAgICAg
ICAiZGlzY291bnRfY2VudHMiOiBkaXNjb3VudCwK
"""),
    ('Report 4: fix time zone offset direction in daily report', """
ZGlmZiAtLWdpdCBhL3RpbGxwb2ludC9yZXBvcnRzLnB5IGIvdGlsbHBvaW50L3JlcG9ydHMucHkKaW5kZXggNWI3YzUyMS4uNTMz
N2IzYSAxMDA2NDQKLS0tIGEvdGlsbHBvaW50L3JlcG9ydHMucHkKKysrIGIvdGlsbHBvaW50L3JlcG9ydHMucHkKQEAgLTcsNyAr
Nyw3IEBAIGZyb20gLiBpbXBvcnQgZGIKIGRlZiBkYXlfYm91bmRzX3V0YyhkYXksIHV0Y19vZmZzZXRfbWludXRlcz0wKToKICAg
ICAiIiJUaGUgVVRDIGluc3RhbnRzIGF0IHdoaWNoIGEgc2hvcC1sb2NhbCBjYWxlbmRhciBkYXkgc3RhcnRzIGFuZCBlbmRzLiBk
YXkgaXMgJ1lZWVktTU0tREQnLiIiIgogICAgIHN0YXJ0ID0gZGF0ZXRpbWUuc3RycHRpbWUoZGF5LCAiJVktJW0tJWQiKS5yZXBs
YWNlKHR6aW5mbz10aW1lem9uZS51dGMpCi0gICAgc3RhcnQgKz0gdGltZWRlbHRhKG1pbnV0ZXM9dXRjX29mZnNldF9taW51dGVz
KQorICAgIHN0YXJ0IC09IHRpbWVkZWx0YShtaW51dGVzPXV0Y19vZmZzZXRfbWludXRlcykgICMgbG9jYWwgPSBVVEMgKyBvZmZz
ZXQsIHNvIFVUQyA9IGxvY2FsIC0gb2Zmc2V0CiAgICAgcmV0dXJuIGRiLnRvX2lzbyhzdGFydCksIGRiLnRvX2lzbyhzdGFydCAr
IHRpbWVkZWx0YShkYXlzPTEpKQogCiAK
"""),
    ('Report 5: reserve stock with one atomic update', """
ZGlmZiAtLWdpdCBhL3RpbGxwb2ludC9jYXRhbG9nLnB5IGIvdGlsbHBvaW50L2NhdGFsb2cucHkKaW5kZXggYjhjZjUyYS4uNDhk
Nzc4YyAxMDA2NDQKLS0tIGEvdGlsbHBvaW50L2NhdGFsb2cucHkKKysrIGIvdGlsbHBvaW50L2NhdGFsb2cucHkKQEAgLTUyLDEx
ICs1MiwxNiBAQCBjbGFzcyBDYXRhbG9nOgogCiAgICAgZGVmIHJlc2VydmUoc2VsZiwgc2t1LCBxdHkpOgogICAgICAgICAiIiJU
YWtlIHF0eSB1bml0cyBvdXQgb2Ygc3RvY2ssIG9yIHJhaXNlIE91dE9mU3RvY2suIiIiCi0gICAgICAgIHByb2R1Y3QgPSBzZWxm
LmdldF9wcm9kdWN0KHNrdSkKLSAgICAgICAgaWYgcHJvZHVjdC5zdG9jayA8IHF0eToKLSAgICAgICAgICAgIHJhaXNlIE91dE9m
U3RvY2soc2t1LCBxdHksIHByb2R1Y3Quc3RvY2spCi0gICAgICAgIHNlbGYuY29ubi5leGVjdXRlKCJVUERBVEUgcHJvZHVjdHMg
U0VUIHN0b2NrID0gc3RvY2sgLSA/IFdIRVJFIHNrdSA9ID8iLCAocXR5LCBza3UpKQorICAgICAgICAjIENoZWNrIGFuZCBzdWJ0
cmFjdCBpbiBPTkUgc3RhdGVtZW50IHNvIHR3byB3b3JrZXJzIGNhbiBuZXZlciBib3RoIHRha2UgdGhlIGxhc3QgdW5pdHMuCisg
ICAgICAgICMgVGhlIGNhY2hlIGlzIHBlciBwcm9jZXNzIGFuZCBjYW4gYmUgb3V0IG9mIGRhdGUsIHNvIGl0IG11c3Qgbm90IGJl
IHVzZWQgZm9yIHRoaXMgY2hlY2suCisgICAgICAgIGN1ciA9IHNlbGYuY29ubi5leGVjdXRlKAorICAgICAgICAgICAgIlVQREFU
RSBwcm9kdWN0cyBTRVQgc3RvY2sgPSBzdG9jayAtID8gV0hFUkUgc2t1ID0gPyBBTkQgc3RvY2sgPj0gPyIsIChxdHksIHNrdSwg
cXR5KSkKICAgICAgICAgc2VsZi5fY2FjaGUucG9wKHNrdSwgTm9uZSkKKyAgICAgICAgaWYgY3VyLnJvd2NvdW50ID09IDA6Cisg
ICAgICAgICAgICByb3cgPSBzZWxmLmNvbm4uZXhlY3V0ZSgiU0VMRUNUIHN0b2NrIEZST00gcHJvZHVjdHMgV0hFUkUgc2t1ID0g
PyIsIChza3UsKSkuZmV0Y2hvbmUoKQorICAgICAgICAgICAgaWYgcm93IGlzIE5vbmU6CisgICAgICAgICAgICAgICAgcmFpc2Ug
VW5rbm93blByb2R1Y3Qoc2t1KQorICAgICAgICAgICAgcmFpc2UgT3V0T2ZTdG9jayhza3UsIHF0eSwgcm93WyJzdG9jayJdKQog
CiAgICAgZGVmIHJlbGVhc2Uoc2VsZiwgc2t1LCBxdHkpOgogICAgICAgICAiIiJQdXQgcXR5IHVuaXRzIGJhY2sgaW50byBzdG9j
ay4iIiIK
"""),
]

TESTS_PY = """
IiIiUmVncmVzc2lvbiB0ZXN0cyBmb3IgcmVwb3J0cyAxLTUuIEVhY2ggb25lIGZhaWxzIG9uIHRoZSBvbGQgY29kZSBhbmQgcGFz
c2VzIG9uIHRoZSBmaXhlZCBjb2RlLiIiIgppbXBvcnQgb3MKaW1wb3J0IHRlbXBmaWxlCmltcG9ydCB1bml0dGVzdAoKZnJvbSB0
aWxscG9pbnQgaW1wb3J0IGRiLCBwcmljaW5nLCByZXBvcnRzCmZyb20gdGlsbHBvaW50LmNhdGFsb2cgaW1wb3J0IENhdGFsb2cs
IE91dE9mU3RvY2sKZnJvbSB0aWxscG9pbnQub3JkZXJzIGltcG9ydCBPcmRlcnMKZnJvbSB0aWxscG9pbnQucGF5bWVudHMgaW1w
b3J0IFBheW1lbnRzCgoKZGVmIG1ha2Vfc2hvcChwYXRoPSI6bWVtb3J5OiIsIHN0b2NrPTEwKToKICAgIGNvbm4gPSBkYi5jb25u
ZWN0KHBhdGgpCiAgICBjYXRhbG9nID0gQ2F0YWxvZyhjb25uKQogICAgY2F0YWxvZy5hZGRfcHJvZHVjdCgiQSIsICJBcHBsZSIs
IDEwMDAsIHN0b2NrKQogICAgY29ubi5leGVjdXRlKCJJTlNFUlQgT1IgSUdOT1JFIElOVE8gY291cG9ucyAoY29kZSwga2luZCwg
dmFsdWUpIFZBTFVFUyAoJ1RFTicsICdwZXJjZW50JywgMTApIikKICAgIHJldHVybiBjb25uLCBjYXRhbG9nCgoKY2xhc3MgRml4
ZXNUZXN0KHVuaXR0ZXN0LlRlc3RDYXNlKToKICAgIGRlZiB0ZXN0X3JlcG9ydDFfcmVwZWF0ZWRfd2ViaG9va19pc19jb3VudGVk
X29uY2Uoc2VsZik6CiAgICAgICAgY29ubiwgY2F0YWxvZyA9IG1ha2Vfc2hvcCgpCiAgICAgICAgb3JkZXIgPSBPcmRlcnMoY29u
biwgY2F0YWxvZykuY3JlYXRlKCJib2IiLCBbKCJBIiwgMSldKQogICAgICAgIHBheW1lbnRzID0gUGF5bWVudHMoY29ubikKICAg
ICAgICBldmVudCA9IHsiaWQiOiAiZXZ0MSIsICJ0eXBlIjogInBheW1lbnQuc3VjY2VlZGVkIiwgIm9yZGVyX2lkIjogb3JkZXJb
ImlkIl0sCiAgICAgICAgICAgICAgICAgImFtb3VudF9jZW50cyI6IG9yZGVyWyJ0b3RhbF9jZW50cyJdfQogICAgICAgIHNlbGYu
YXNzZXJ0RXF1YWwocGF5bWVudHMuaGFuZGxlX2V2ZW50KGV2ZW50KSwgInBhaWQiKQogICAgICAgIHNlbGYuYXNzZXJ0RXF1YWwo
cGF5bWVudHMuaGFuZGxlX2V2ZW50KGV2ZW50KSwgInBhaWQiKSAgIyBwcm92aWRlciByZXRyeQogICAgICAgIHNlbGYuYXNzZXJ0
RXF1YWwocGF5bWVudHMucGFpZF9jZW50cyhvcmRlclsiaWQiXSksIG9yZGVyWyJ0b3RhbF9jZW50cyJdKQoKICAgIGRlZiB0ZXN0
X3JlcG9ydDJfY2FuY2VsbGluZ19wZW5kaW5nX29yZGVyX3JldHVybnNfc3RvY2soc2VsZik6CiAgICAgICAgY29ubiwgY2F0YWxv
ZyA9IG1ha2Vfc2hvcChzdG9jaz0xMCkKICAgICAgICBvcmRlcnMgPSBPcmRlcnMoY29ubiwgY2F0YWxvZykKICAgICAgICBvcmRl
ciA9IG9yZGVycy5jcmVhdGUoImJvYiIsIFsoIkEiLCA0KV0pCiAgICAgICAgc2VsZi5hc3NlcnRFcXVhbChjYXRhbG9nLmdldF9w
cm9kdWN0KCJBIikuc3RvY2ssIDYpCiAgICAgICAgb3JkZXJzLmNhbmNlbChvcmRlclsiaWQiXSkKICAgICAgICBzZWxmLmFzc2Vy
dEVxdWFsKGNhdGFsb2cuZ2V0X3Byb2R1Y3QoIkEiKS5zdG9jaywgMTApCgogICAgZGVmIHRlc3RfcmVwb3J0M190YXhfaXNfb25f
dGhlX2Rpc2NvdW50ZWRfcHJpY2Uoc2VsZik6CiAgICAgICAgY291cG9uID0geyJjb2RlIjogIlRFTiIsICJraW5kIjogInBlcmNl
bnQiLCAidmFsdWUiOiAxMCwgIm1pbl9zdWJ0b3RhbF9jZW50cyI6IDAsCiAgICAgICAgICAgICAgICAgICJtYXhfdXNlcyI6IE5v
bmUsICJ1c2VzIjogMH0KICAgICAgICB0b3RhbHMgPSBwcmljaW5nLnByaWNlX29yZGVyKFsoMTAwMCwgMSldLCAiQ0EiLCBjb3Vw
b24pCiAgICAgICAgc2VsZi5hc3NlcnRFcXVhbCh0b3RhbHNbImRpc2NvdW50X2NlbnRzIl0sIDEwMCkKICAgICAgICBzZWxmLmFz
c2VydEVxdWFsKHRvdGFsc1sidGF4X2NlbnRzIl0sIDY1KSAgICAgICAjIDcuMjUlIG9mIDkwMAogICAgICAgIHNlbGYuYXNzZXJ0
RXF1YWwodG90YWxzWyJ0b3RhbF9jZW50cyJdLCA5NjUpCgogICAgZGVmIHRlc3RfcmVwb3J0NF9kYXlfYm91bmRzX2Zvcl91dGNf
cGx1c181MzAoc2VsZik6CiAgICAgICAgc3RhcnQsIGVuZCA9IHJlcG9ydHMuZGF5X2JvdW5kc191dGMoIjIwMjYtMTEtMjEiLCAz
MzApCiAgICAgICAgc2VsZi5hc3NlcnRFcXVhbChzdGFydCwgIjIwMjYtMTEtMjBUMTg6MzA6MDBaIikKICAgICAgICBzZWxmLmFz
c2VydEVxdWFsKGVuZCwgIjIwMjYtMTEtMjFUMTg6MzA6MDBaIikKCiAgICBkZWYgdGVzdF9yZXBvcnQ0X21vcm5pbmdfc2FsZV9p
bl9pbmRpYV9pc19pbl90aGF0X2RheXNfcmVwb3J0KHNlbGYpOgogICAgICAgIGNvbm4sIGNhdGFsb2cgPSBtYWtlX3Nob3AoKQog
ICAgICAgIG9yZGVyID0gT3JkZXJzKGNvbm4sIGNhdGFsb2cpLmNyZWF0ZSgiYm9iIiwgWygiQSIsIDEpXSkKICAgICAgICAjIDA4
OjAwIEluZGlhIHRpbWUgb24gMjEgTm92ID0gMDI6MzAgVVRDIG9uIDIxIE5vdgogICAgICAgIGV2ZW50ID0geyJpZCI6ICJlMSIs
ICJ0eXBlIjogInBheW1lbnQuc3VjY2VlZGVkIiwgIm9yZGVyX2lkIjogb3JkZXJbImlkIl0sCiAgICAgICAgICAgICAgICAgImFt
b3VudF9jZW50cyI6IG9yZGVyWyJ0b3RhbF9jZW50cyJdfQogICAgICAgIFBheW1lbnRzKGNvbm4pLmhhbmRsZV9ldmVudChldmVu
dCwgbm93PWRiLmZyb21faXNvKCIyMDI2LTExLTIxVDAyOjMwOjAwWiIpKQogICAgICAgIHJlcG9ydCA9IHJlcG9ydHMuZGFpbHlf
c2FsZXMoY29ubiwgIjIwMjYtMTEtMjEiLCAzMzApCiAgICAgICAgc2VsZi5hc3NlcnRFcXVhbChyZXBvcnRbInJldmVudWVfY2Vu
dHMiXSwgb3JkZXJbInRvdGFsX2NlbnRzIl0pCgogICAgZGVmIHRlc3RfcmVwb3J0NV90d29fd29ya2Vyc19jYW5ub3Rfb3ZlcnNl
bGwoc2VsZik6CiAgICAgICAgcGF0aCA9IG9zLnBhdGguam9pbih0ZW1wZmlsZS5ta2R0ZW1wKCksICJzaG9wLmRiIikKICAgICAg
ICBjb25uMSwgY2F0YWxvZzEgPSBtYWtlX3Nob3AocGF0aCwgc3RvY2s9NSkKICAgICAgICBjb25uMiA9IGRiLmNvbm5lY3QocGF0
aCkKICAgICAgICBjYXRhbG9nMiA9IENhdGFsb2coY29ubjIpCiAgICAgICAgY2F0YWxvZzEuZ2V0X3Byb2R1Y3QoIkEiKQogICAg
ICAgIGNhdGFsb2cyLmdldF9wcm9kdWN0KCJBIikgICAgICAgICAgICAgICAgICAgICAgIyBib3RoIHdvcmtlcnMgaGF2ZSBhIGNh
Y2hlZCBjb3B5OiBzdG9jayA1CiAgICAgICAgT3JkZXJzKGNvbm4xLCBjYXRhbG9nMSkuY3JlYXRlKCJhIiwgWygiQSIsIDUpXSkK
ICAgICAgICB3aXRoIHNlbGYuYXNzZXJ0UmFpc2VzKE91dE9mU3RvY2spOgogICAgICAgICAgICBPcmRlcnMoY29ubjIsIGNhdGFs
b2cyKS5jcmVhdGUoImIiLCBbKCJBIiwgNSldKQogICAgICAgIHN0b2NrID0gY29ubjEuZXhlY3V0ZSgiU0VMRUNUIHN0b2NrIEZS
T00gcHJvZHVjdHMgV0hFUkUgc2t1ID0gJ0EnIikuZmV0Y2hvbmUoKVswXQogICAgICAgIHNlbGYuYXNzZXJ0RXF1YWwoc3RvY2ss
IDApCiAgICAgICAgY29ubjEuY2xvc2UoKQogICAgICAgIGNvbm4yLmNsb3NlKCkKCgppZiBfX25hbWVfXyA9PSAiX19tYWluX18i
OgogICAgdW5pdHRlc3QubWFpbigpCg==
"""

GITIGNORE = "__pycache__/\n*.pyc\n*.db\nmake_commits.py\n"


def git(*args, check=True, data=None):
    result = subprocess.run(["git", *args], input=data, capture_output=True)
    if check and result.returncode != 0:
        print("\nGit command failed:", "git", *args)
        print(result.stderr.decode(errors="replace"))
        sys.exit(1)
    return result


def main():
    for needed in ("tillpoint", "tests", "NOTES.md", "server.py"):
        if not os.path.exists(needed):
            sys.exit(f"Run this from the project folder. I cannot see '{needed}' here.")
    if os.path.exists(".git"):
        sys.exit("This folder already has git (.git). Stop here so nothing is overwritten.")
    name = git("config", "--global", "user.name", check=False).stdout.decode().strip()
    email = git("config", "--global", "user.email", check=False).stdout.decode().strip()
    if not name or not email:
        sys.exit('Git does not know who you are. Run these two lines first, with your own name and email:\n'
                 '  git config --global user.name "Your Name"\n'
                 '  git config --global user.email "you@example.com"')

    git("init")
    git("config", "core.autocrlf", "false")
    patches = [(m, base64.b64decode("".join(b.split()))) for m, b in PATCHES]

    # 1. Put the 5 files back to the ORIGINAL (buggy) version so the first commit is the starting point.
    for _, data in reversed(patches):
        check = git("apply", "-R", "--check", "--ignore-whitespace", "-", check=False, data=data)
        if check.returncode != 0:
            sys.exit("Your tillpoint files are not exactly my fixed files, so I cannot continue.\n"
                     "Copy the 5 fixed files again (payments, orders, pricing, reports, catalog) and retry.\n"
                     "Also delete the .git folder that was just created.")
    for _, data in reversed(patches):
        git("apply", "-R", "--ignore-whitespace", "-", data=data)

    with open(".gitignore", "w", newline="\n") as f:
        f.write(GITIGNORE)
    git("add", "-A")
    git("commit", "-m", "Starting point: Tillpoint assignment as received")

    # 2. One commit per fix.
    for message, data in patches:
        git("apply", "--ignore-whitespace", "-", data=data)
        git("add", "-A")
        git("commit", "-m", message)

    # 3. The tests that prove the fixes.
    with open(os.path.join("tests", "test_fixes.py"), "wb") as f:
        f.write(base64.b64decode("".join(TESTS_PY.split())))
    git("add", "-A")
    git("commit", "-m", "Add regression tests for reports 1-5")

    print(git("log", "--oneline").stdout.decode())
    print("Done. Copy these short codes into the Commits: field in NOTES.md.")


main()